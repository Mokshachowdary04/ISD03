i18next.init({
    lng: 'en', // Default language
    debug: true,
    resources: {
        en: {
            translation: {
                "home": "Home",
                "predict": "Predict",
                "description": "Description",
                "about": "About",
                "contact": "Contact",
                "welcome": "Welcome to Fertilizer Prediction",
                "proceed": "Proceed",
                "temperature": "Temperature",
                "humidity": "Humidity (%)",
                "moisture": "Moisture",
                "black_soil": "Black",
                "clayey_soil": "Clayey",
                "loamy_soil": "Loamy",
                "red_soil": "Red",
                "sandy_soil": "Sandy",
                "barley": "Barley",
                "cotton": "Cotton",
                "ground_nuts": "Ground Nuts",
                "maize": "Maize",
                "millets": "Millets",
                "oil_seeds": "Oil Seeds",
                "paddy": "Paddy",
                "pulses": "Pulses",
                "sugarcane": "Sugarcane",
                "tobacco": "Tobacco",
                "wheat": "Wheat",
                "nitrogen": "Nitrogen",
                "potassium": "Potassium",
                "phosphorous": "Phosphorous",
                "predict_fertilizer": "Predict Fertilizer",
//description

    "description_heading": "Description",
    "description_text": "This project predicts the type of fertilizer to be used based on crop and soil type. The dataset is sourced from <a href='https://www.kaggle.com/gdabhishek/fertilizer-prediction' target='_blank'>Kaggle</a>.",
    "variable_details": "Variable Details:",
    "nitrogen": "N (Nitrogen): Essential for plant growth and chlorophyll production.",
    "phosphorus": "P (Phosphorus): Helps store and transfer energy for plant growth.",
    "potassium": "K (Potassium): Critical nutrient for plant health.",
    "temperature": "Temperature: Affects plant metabolism and growth.",
    "humidity": "Humidity: Impacts plant diseases and pest attraction.",
    "soil_type": "Soil Type: Determines soil fertility and crop suitability.",
    "crop_type": "Crop Type: Helps determine optimal fertilizer.",
    "label_output": "Label (Output Variable): Includes 22 unique fertilizer types like Urea, DAP, 10-26-26, etc.",
    "algorithm_accuracy": "Algorithm & Accuracy:",
    "logistic_regression": "Logistic Regression: 90% accuracy.",
    "random_forest": "Random Forest Classifier: 98% accuracy (used for final model).",
    "uniqueness_heading": "Uniqueness:",
    "uniqueness_text": "This project stands out because it combines <span class='highlight'>agriculture with machine learning</span> to help farmers make data-driven decisions. The high accuracy of the model ensures <span class='highlight'>reliable recommendations</span> for improving crop yield and sustainability.",


                //about
                "about_heading": "About",
    "about_text": "EasyGrow is a revolutionary tool designed to help farmers apply fertilizers with precision and confidence. By analyzing key environmental factors like temperature, humidity, soil conditions, CO2 levels, and more, EasyGrow predicts the exact fertilizer needs for any crop. This smart system takes the guesswork out of farming, ensuring optimal growth while reducing waste and costs. Tailored to each farm’s unique conditions, it delivers accurate, real-time recommendations that boost yields and promote sustainability.",
    "contact_heading": "Contact",
    "name": "Name: Sushmanth Pinisetty",
    "email": "Email: Sushmanthpinisetty@gmail.com",
    "phone": "Phone: +91 83744 12183",
    "address": "Address: Adhiganahalli, Rajanukunte, Yelahanka, India"
            }
        },
        kn: {
            translation: {
                "home": "ಮನೆ",
                "predict": "ಭವಿಷ್ಯವಾಣಿ",
                "description": "ವಿವರಣೆ",
                "about": "ಬಗ್ಗೆ",
                "contact": "ಸಂಪರ್ಕ",
                "welcome": "ಸೇಕರಿಸುವಿಕೆಗೆ ಸುಸ್ವಾಗತ",
                "proceed": "ಮುಂದುವರಿಸಿ",
                "temperature": "ತಾಪಮಾನ",
                "humidity": "ಆಕಾಸಿ ತೇವ (%)",
                "moisture": "ನೀರು",
                "black_soil": "ಕಪ್ಪು",
                "clayey_soil": "ಮಣ್ಣಿನ",
                "loamy_soil": "ಮಣ್ಣಿನ",
                "red_soil": "ಕೆಂಪು",
                "sandy_soil": "ಮಣ್ಣು",
                "barley": "ಜೋಳ",
                "cotton": "ಕಬ್ಬು",
                "ground_nuts": "ಭೂಕಬ್ಬು",
                "maize": "ಮಕ್ಕಾ",
                "millets": "ಜೋಳ",
                "oil_seeds": "ಎಣ್ಣೆ ಬೀಜಗಳು",
                "paddy": "ಅಕ್ಕಿ",
                "pulses": "ಪೊಪ್ಪು",
                "sugarcane": "ಕ್ಕು",
                "tobacco": "ಬೇರು",
                "wheat": "ಗೋಧಿ",
                "nitrogen": "ನೈಟ್ರೋಜನ್",
                "potassium": "ಪೊಟ್ಯಾಸಿಯಮ್",
                "phosphorous": "ಫಾಸ್ಫರಸ್",
                "predict_fertilizer": "ಎರುವು ಊಹಿಸಿ",
                
//discrition

    "description_heading": "ವಿವರಣೆ",
    "description_text": "ಈ ಯೋಜನೆ ಬೆಳೆ ಮತ್ತು ಮಣ್ಣಿನ ಪ್ರಕಾರವನ್ನು ಆಧರಿಸಿ ಬಳಸಬೇಕಾದ ರಸಗೊಬ್ಬರದ ವಿಧವನ್ನು ಭವಿಷ್ಯವಾಣಿಿಸುತ್ತದೆ. ಡೇಟಾಸೆಟ್ ಅನ್ನು <a href='https://www.kaggle.com/gdabhishek/fertilizer-prediction' target='_blank'>Kaggle</a> ನಿಂದ ಪಡೆಯಲಾಗಿದೆ.",
    "variable_details": "ಚರಾಂಶದ ವಿವರಗಳು:",
    "nitrogen": "N (ನೈಟ್ರೋಜನ್): ಸಸ್ಯ ವೃದ್ಧಿ ಮತ್ತು ಹಸಿರು ಪರಿಕಲ್ಪನೆಗೆ ಅಗತ್ಯವಾಗಿದೆ.",
    "phosphorus": "P (ಫಾಸ್ಫರಸ್): ಸಸ್ಯ ವೃದ್ಧಿಗಾಗಿ ಶಕ್ತಿ ಸಂಗ್ರಹಿಸಿ ಮತ್ತು ವರ್ಗಾಯಿಸಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ.",
    "potassium": "K (ಪೊಟ್ಯಾಷಿಯಮ್): ಸಸ್ಯ ಆರೋಗ್ಯಕ್ಕೆ ಪ್ರಮುಖ ಪೋಷಕಾಂಶ.",
    "temperature": "ತಾಪಮಾನ: ಸಸ್ಯ ಶ್ವಾಸಕ್ರಿಯೆಯನ್ನು ಮತ್ತು ವೃದ್ಧಿಯನ್ನು ಪ್ರಭಾವಿಸುತ್ತದೆ.",
    "humidity": "ಆದ್ರತೆ: ಸಸ್ಯ ರೋಗಗಳು ಮತ್ತು ಕೀಟದ ಆಕರ್ಷಣೆಯನ್ನು ಪ್ರಭಾವಿಸುತ್ತದೆ.",
    "soil_type": "ಮಣ್ಣಿನ ಪ್ರಕಾರ: ಮಣ್ಣಿನ ಸಾರದ ಮತ್ತು ಬೆಳೆ ಸೂಕ್ತತೆಯನ್ನು ನಿರ್ಧರಿಸುತ್ತದೆ.",
    "crop_type": "ಬೆಳೆ ಪ್ರಕಾರ: ರಸಗೊಬ್ಬರವನ್ನು ನಿರ್ಧರಿಸಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ.",
    "label_output": "ಲೇಬಲ್ (ಔಟ್‌ಪುಟ್ ವೆರಿಯಬಲ್): Urea, DAP, 10-26-26 ಮುಂತಾದ 22 ವಿಭಿನ್ನ ರಸಗೊಬ್ಬರಗಳನ್ನು ಒಳಗೊಂಡಿದೆ.",
    "algorithm_accuracy": "ಅಲ್ಗೊರಿದಮ್ & ನಿಖರತೆ:",
    "logistic_regression": "ಲಾಜಿಕ್ಸ್ಟಿಕ್ ರಿಗ್ರೆಷನ್: 90% ನಿಖರತೆ.",
    "random_forest": "ರ್ಯಾಂಡಮ್ ಫಾರೆಸ್ಟ್ ಕ್ಲಾಸಿಫೈಯರ್: 98% ನಿಖರತೆ (ಅಂತಿಮ ಮಾದರಿಗಾಗಿ ಬಳಸಲಾಗಿದೆ).",
    "uniqueness_heading": "ವಿಶಿಷ್ಟತೆ:",
    "uniqueness_text": "ಈ ಯೋಜನೆ <span class='highlight'>ಕೃಷಿಯನ್ನು ಮೆಷಿನ್ ಲರ್ನಿಂಗ್</span> ಜೊತೆ ಹೊಂದಿಸಿ ಡೇಟಾ ಆಧಾರಿತ ನಿರ್ಣಯಗಳನ್ನು ಕೈಗೊಳ್ಳಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ. ಮಾದರಿಯ ಉನ್ನತ ನಿಖರತೆಯು <span class='highlight'>ವಿಶ್ವಾಸಾರ್ಹ ಶಿಫಾರಸುಗಳು</span> ಒದಗಿಸುತ್ತದೆ.",

                //about
                    "about_heading": "ಬಗ್ಗೆ",
                    "about_text": "EasyGrow ರೈತರಿಗೆ ನಿಖರವಾಗಿ ಮತ್ತು ಆತ್ಮವಿಶ್ವಾಸದಿಂದ ರಸಗೊಬ್ಬರ ಬಳಸಲು ಸಹಾಯ ಮಾಡುತ್ತದೆ. ತಾಪಮಾನ, ಆದ್ರತೆ, ಮಣ್ಣಿನ ಪರಿಸ್ಥಿತಿಗಳು, CO2 ಮಟ್ಟ ಮತ್ತು ಇತರ ಪರಿಸರಘಟಕಗಳನ್ನು ವಿಶ್ಲೇಷಿಸುವ ಮೂಲಕ, EasyGrow ಯಾವುದೇ ಬೆಳೆಗಾಗಿ ಸರಿಯಾದ ರಸಗೊಬ್ಬರದ ಅಗತ್ಯವನ್ನು ಭವಿಷ್ಯವಾಣಿ ಮಾಡುತ್ತದೆ. ಈ ಬುದ್ಧಿವಂತ ವ್ಯವಸ್ಥೆ ಕೃಷಿಯಲ್ಲಿ ಊಹೆಗಳನ್ನು ತೆಗೆದು ಹಾಕುತ್ತದೆ, ಉತ್ತಮ ಬೆಳವಣಿಗೆ ಖಚಿತಪಡಿಸುತ್ತದೆ ಮತ್ತು ವ್ಯಯವನ್ನು ಮತ್ತು ವೆಚ್ಚವನ್ನು ಕಡಿಮೆ ಮಾಡುತ್ತದೆ. ಪ್ರತಿ ಕೃಷಿ ಕ್ಷೇತ್ರದ ವಿಶಿಷ್ಟ ಪರಿಸ್ಥಿತಿಗಳಿಗೆ ಹೊಂದಿಕೊಳ್ಳುವಂತೆ, ಇದು ಉತ್ಪಾದನೆಯನ್ನು ಹೆಚ್ಚಿಸಲು ಮತ್ತು ಶಾಶ್ವತತೆಯನ್ನು ಉತ್ತೇಜಿಸಲು ನಿಖರವಾದ, ನಿಖರವಾದ ಶಿಫಾರಸುಗಳನ್ನು ಒದಗಿಸುತ್ತದೆ.",
                    "contact_heading": "ಸಂಪರ್ಕ",
                    "name": "ಹೆಸರು: ಸುಷ್ಮಂತ್ ಪಿನಿಸೆಟ್ಟಿ",
                    "email": "ಇಮೇಲ್: Sushmanthpinisetty@gmail.com",
                    "phone": "ದೂರವಾಣಿ: +91 83744 12183",
                    "address": "ವಿಳಾಸ: ಅಧಿಗನಹಳ್ಳಿ, ರಾಜನುಕುಂಟೆ, ಯಲಹಂಕ, ಭಾರತ"
                
            }
        },
        ta: {
            translation: {
                "home": "முகப்பு",
                "predict": "முன்னறிவிப்பு",
                "description": "விளக்கம்",
                "about": "பற்றி",
                "contact": "தொடர்பு",
                "welcome": "உரிய உரம் கணிப்பு",
                "proceed": "தொடரவும்",
                //predict
                "temperature": "வெப்பநிலை",
                "humidity": "ஊறுகாய் (%)",
                "moisture": "ஊறுகாய்",
                "black_soil": "கருப்பு",
                "clayey_soil": "மண்ணில்",
                "loamy_soil": "மண்ணில்",
                "red_soil": "சிகப்பு",
                "sandy_soil": "மண்",
                "barley": "பருத்தி",
                "cotton": "பருத்தி",
                "ground_nuts": "மூங்கில்",
                "maize": "மக்காச்சோளம்",
                "millets": "சோளம்",
                "oil_seeds": "எண்ணெய் விதைகள்",
                "paddy": "அக்கி",
                "pulses": "பொறி",
                "sugarcane": "சர்க்கரை cane",
                "tobacco": "புகை",
                "wheat": "கோதுமை",
                "nitrogen": "நைட்ரஜன்",
                "potassium": "பொட்டாசியம்",
                "phosphorous": "பாஸ்பரஸ்",
                "predict_fertilizer": "எரிவாயு கணிக்கவும்",
                //description

                
                    "description_heading": "விளக்கம்",
                    "description_text": "இந்த திட்டம் பயிர் மற்றும் மண் வகையை அடிப்படையாகக் கொண்டு பயன்படுத்த வேண்டிய உரத்தின் வகையை கணிக்கிறது. தரவுத்தொகுப்பு <a href='https://www.kaggle.com/gdabhishek/fertilizer-prediction' target='_blank'>Kaggle</a> இல் இருந்து பெறப்பட்டுள்ளது.",
                    "variable_details": "மாறிலி விவரங்கள்:",
                    "nitrogen": "N (நைட்ரஜன்): செடியின் வளர்ச்சி மற்றும் குளோரோபில் உற்பத்திக்கு அவசியம்.",
                    "phosphorus": "P (பாஸ்பரஸ்): செடியின் வளர்ச்சிக்கு சக்தியை சேமிக்கவும் மாற்றவும் உதவுகிறது.",
                    "potassium": "K (பொட்டாசியம்): செடியின் ஆரோக்கியத்திற்கு முக்கியமான ஊட்டச்சத்து.",
                    "temperature": "வெப்பநிலை: செடியின் உளவியல் மற்றும் வளர்ச்சியை பாதிக்கிறது.",
                    "humidity": "ஊறுகாய்: செடியின் நோய்கள் மற்றும் பூச்சிகளை ஈர்க்கிறது.",
                    "soil_type": "மண் வகை: மண்ணின் பயிர் உகந்த தன்மையை தீர்மானிக்கிறது.",
                    "crop_type": "பயிர் வகை: சரியான உரத்தை தீர்மானிக்க உதவுகிறது.",
                    "label_output": "லேபிள் (வெளியீட்டு மாறிலி): Urea, DAP, 10-26-26 போன்ற 22 தனித்துவமான உர வகைகளை உள்ளடக்கியது.",
                    "algorithm_accuracy": "அல்கோரிதம் & துல்லியம்:",
                    "logistic_regression": "லாஜிஸ்டிக் ரிக்ரெஷன்: 90% துல்லியம்.",
                    "random_forest": "ரேண்டம் ஃபாரஸ்ட் கிளாஸிஃபையர்: 98% துல்லியம் (இறுதி மாதிரிக்காக பயன்படுத்தப்பட்டது).",
                    "uniqueness_heading": "விசேஷம்:",
                    "uniqueness_text": "இந்த திட்டம் <span class='highlight'>விவசாயத்தை மெஷின் லெர்னிங்</span> உடன் இணைத்து விவசாயிகளுக்கு தரவுகளை அடிப்படையாகக் கொண்டு முடிவுகளை எடுக்க உதவுகிறது. மாதிரியின் உயர் துல்லியம் <span class='highlight'>நம்பகமான பரிந்துரைகளை</span> வழங்குகிறது.",
                    
                //about
                    "about_heading": "பற்றி",
                    "about_text": "EasyGrow என்பது விவசாயிகளுக்கு உரங்களை துல்லியமாகவும் நம்பிக்கையுடன் பயன்படுத்த உதவுவதற்காக வடிவமைக்கப்பட்ட ஒரு புரட்சிகரமான கருவி ஆகும். EasyGrow, வெப்பநிலை, ஈரப்பதம், மண் நிலைகள், CO2 அளவுகள் மற்றும் மேலும் பல முக்கிய சுற்றுச்சூழல் காரணிகளை பகுப்பாய்வு செய்வதன் மூலம், எந்த பயிருக்கும் சரியான உர தேவைகளை கணிக்கிறது. இந்த புத்திசாலி அமைப்பு விவசாயத்தில் ஊகங்களை நீக்குகிறது, சிறந்த வளர்ச்சியை உறுதி செய்கிறது மற்றும் வீணாகும் மற்றும் செலவுகளை குறைக்கிறது. ஒவ்வொரு விவசாயத்தின் தனிப்பட்ட நிலைகளுக்கு ஏற்ப, இது விளைவுகளை அதிகரிக்க மற்றும் நிலைத்தன்மையை ஊக்குவிக்க துல்லியமான, நேரடி பரிந்துரைகளை வழங்குகிறது.",
                    "contact_heading": "தொடர்பு",
                    "name": "பெயர்: சுஷ்மந்த் பினிசெட்டி",
                    "email": "மின்னஞ்சல்: Sushmanthpinisetty@gmail.com",
                    "phone": "தொலைபேசி: +91 83744 12183",
                    "address": "முகவரி: ஆதிகனಹள்ளி, ராஜனுகுண்டே, யelahanka, இந்தியா"
                
            }
        },
        te: {
            translation: {
                "home": "హోమ్",
                "predict": "అంచనా",
                "description": "వివరణ",
                "about": "గురించి",
                "contact": "సంప్రదించండి",
                "welcome": "ఎరువు అంచనా కు స్వాగతం",
                "proceed": "కొనసాగించండి",
                "temperature": "ఉష్ణోగ్రత",
                "humidity": "ఆర్ద్రత (%)",
                "moisture": "నీరు",
                "black_soil": "నల్ల మట్టి",
                "clayey_soil": "మట్టి",
                "loamy_soil": "మట్టి",
                "red_soil": "ఎరుపు మట్టి",
                "sandy_soil": "మట్టి",
                "barley": "జొన్న",
                "cotton": "కత్తి",
                "ground_nuts": "భూమి కప్పలు",
                "maize": "మక్కా",
                "millets": "జొన్న",
                "oil_seeds": "నూనె బీజాలు",
                "paddy": "అక్కి",
                "pulses": "పప్పులు",
                "sugarcane": "చక్కెర కంచ",
                "tobacco": "తంబాకు",
                "wheat": "గోధుమ",
                "nitrogen": "నైట్రోజన్",
                "potassium": "పొటాషియం",
                "phosphorous": "ఫాస్ఫరస్",
                "predict_fertilizer": "ఎరువును అంచనా వేయండి",
                //description
                
                    "description_heading": "గురించి",
                    "description_text": "ఈ ప్రాజెక్ట్ పంట మరియు మట్టిని ఆధారంగా తీసుకుని ఉపయోగించాల్సిన ఎరువుల రకాన్ని అంచనా వేస్తుంది. డేటాసెట్ <a href='https://www.kaggle.com/gdabhishek/fertilizer-prediction' target='_blank'>Kaggle</a> నుండి పొందబడింది.",
                    "variable_details": "చరామశాల వివరాలు:",
                    "nitrogen": "N (నైట్రోజన్): మొక్కల వృద్ధి మరియు క్లోరోఫిల్ ఉత్పత్తికి అవసరం.",
                    "phosphorus": "P (ఫాస్ఫరస్): మొక్కల వృద్ధికి శక్తిని నిల్వ చేయడానికి మరియు బదిలీ చేయడానికి సహాయపడుతుంది.",
                    "potassium": "K (పొటాషియం): మొక్కల ఆరోగ్యానికి కీలకమైన పోషకాలు.",
                    "temperature": "ఉష్ణోగ్రత: మొక్కల జీవక్రియ మరియు వృద్ధిని ప్రభావితం చేస్తుంది.",
                    "humidity": "ఆద్రత: మొక్కల రోగాలు మరియు కీటకాలను ఆకర్షించడంలో ప్రభావం చూపిస్తుంది.",
                    "soil_type": "మట్టివర్గం: మట్టికి పంటకు అనుకూలతను నిర్ధారిస్తుంది.",
                    "crop_type": "పంట రకం: సరైన ఎరువును నిర్ణయించడంలో సహాయపడుతుంది.",
                    "label_output": "లేబుల్ (అవుట్‌పుట్ వేరియబుల్): Urea, DAP, 10-26-26 వంటి 22 ప్రత్యేక ఎరువుల రకాలను కలిగి ఉంది.",
                    "algorithm_accuracy": "అల్గోరిథం & ఖచ్చితత్వం:",
                    "logistic_regression": "లాజిస్టిక్ రిగ్రెషన్: 90% ఖచ్చితత్వం.",
                    "random_forest": "రాండమ్ ఫారెస్ట్ క్లాసిఫైయర్: 98% ఖచ్చితత్వం (చివరి మోడల్ కోసం ఉపయోగించబడింది).",
                    "uniqueness_heading": "విశిష్టత:",
                    "uniqueness_text": "ఈ ప్రాజెక్ట్ <span class='highlight'>వ్యవసాయాన్ని మెషిన్ లెర్నింగ్</span> తో కలిపి రైతులకు డేటా ఆధారిత నిర్ణయాలు తీసుకోవడంలో సహాయపడుతుంది. మోడల్ యొక్క అధిక ఖచ్చితత్వం <span class='highlight'>నమ్మకమైన సిఫారసులను</span> అందించడానికి నిర్ధారిస్తుంది." ,
                    
                //about
                    "about_heading": "గురించి",
                    "about_text": "EasyGrow అనేది రైతులకు ఖచ్చితంగా మరియు నమ్మకంగా ఎరువులు ఉపయోగించడానికి సహాయపడే విప్లవాత్మక సాధనం. EasyGrow, ఉష్ణోగ్రత, ఆర్ద్రత, మట్టి పరిస్థితులు, CO2 స్థాయిలు మరియు మరిన్ని ముఖ్యమైన పర్యావరణ కారకాలను విశ్లేషించడం ద్వారా, ఏ పంటకు సరైన ఎరువుల అవసరాలను అంచనా వేస్తుంది. ఈ తెలివైన వ్యవస్థ వ్యవసాయంలో ఊహలను తీసివేస్తుంది, ఉత్తమ వృద్ధిని నిర్ధారిస్తుంది మరియు వ్యయాన్ని మరియు ఖర్చులను తగ్గిస్తుంది. ప్రతి వ్యవసాయానికి ప్రత్యేకమైన పరిస్థితులకు అనుగుణంగా, ఇది దిగుబడులను పెంచడానికి మరియు స్థిరత్వాన్ని ప్రోత్సహించడానికి ఖచ్చితమైన, తక్షణ సిఫారసులను అందిస్తుంది.",
                    "contact_heading": "సంప్రదించండి",
                    "name": "పేరు: సుష్మంత్ పినిసెట్టి",
                    "email": "ఇమెయిల్: Sushmanthpinisetty@gmail.com",
                    "phone": "ఫోన్: +91 83744 12183",
                    "address": "చిరునామా: అధిగనహల్లి, రాజనుకుంటే, యలహంక, భారత్"
                
            }
        }
    }
}, function(err, t) {
    updateContent();
});
function updateContent() {
    document.querySelectorAll("[data-i18n]").forEach((el) => {
        el.innerHTML = i18next.t(el.getAttribute("data-i18n"));
    });

    // Handle input placeholders
    document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => {
        el.setAttribute("placeholder", i18next.t(el.getAttribute("data-i18n-placeholder")));
    });
}


function changeLanguage() {
    const selectedLanguage = document.getElementById('language').value;
    i18next.changeLanguage(selectedLanguage, updateContent);
}
