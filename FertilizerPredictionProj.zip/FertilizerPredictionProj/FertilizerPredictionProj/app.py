from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import pickle

app = Flask(__name__)
app.secret_key = "secret"

# Dummy login credentials
USERNAME = "user"
PASSWORD = "user"

# Importing pickle files
model = pickle.load(open('classifier.pkl', 'rb'))
ferti = pickle.load(open('fertilizer.pkl', 'rb'))


@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username == USERNAME and password == PASSWORD:
            session["logged_in"] = True
            return redirect(url_for("home"))
        else:
            return render_template("loginPage.html", error="Invalid Credentials! Try again.")

    return render_template("loginPage.html")


@app.route("/home")
def home():
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return render_template("HomePage.html")  # Ensure this file contains the navbar and form


@app.route('/predict', methods=['POST'])
def predict():
    try:
        temp = request.form.get('temp')
        humi = request.form.get('humid')
        mois = request.form.get('mois')
        soil = request.form.get('soil')
        crop = request.form.get('crop')
        nitro = request.form.get('nitro')
        pota = request.form.get('pota')
        phosp = request.form.get('phos')

        input_data = [int(temp), int(humi), int(mois), int(soil), int(crop), int(nitro), int(pota), int(phosp)]

        # Get prediction
        res = ferti.classes_[model.predict([input_data])[0]]

        return jsonify({'prediction': f'Predicted Fertilizer is {res}'})  # Return JSON response

    except Exception as e:
        return jsonify({'error': str(e)})


if __name__ == "__main__":
    app.run(debug=True)
